Myanmar Legends RPG - APK Project

ဒီ project က မင်းရဲ့ index.html game ကို Android WebView app အဖြစ်ထည့်ထားတာပါ။

ဖုန်းကနေ APK build လုပ်ချင်ရင်:
1. Project folder ကို GitHub repository တစ်ခုထဲ upload လုပ်ပါ။
2. GitHub > Actions ကိုဖွင့်ပါ။
3. "Build APK" workflow ကိုရွေးပါ။
4. "Run workflow" နှိပ်ပါ။
5. Build ပြီးရင် Artifacts ထဲက MyanmarLegendsRPG-debug ကို download လုပ်ပါ။

မှတ်ချက်:
- ဒီ build က debug APK ဖြစ်ပါတယ်။
- Game data က app ထဲက assets/index.html မှာပါ။
- Acode က HTML ကိုပြင်/စမ်းဖို့ အသုံးဝင်ပြီး APK build system ကိုတော့ Android/Gradle project က လုပ်ပါတယ်။
